# -*- coding: utf-8 -*-
from .backcall import callback_prototype

__author__ = 'Thomas Kluyver'
__email__ = 'takowl@gmail.com'
__version__ = '0.1.0'